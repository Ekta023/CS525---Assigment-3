#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "dberror.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "dt.h"
typedef struct Frame {
    PageNumber pageNum;
    char *data;
    bool isDirty;   //bool to cheeck if page is modified
    int fixCount;
    int loadTime;   //timestamp for FIFO
    int *accessHistory;
    int k;
} Frame;

typedef struct BP_MgmtData {
    Frame *frames;
    int numFrames;   //total number of frames in buffer pool
    SM_FileHandle fh;
    ReplacementStrategy strategy;
    int readCount;  //number of disk reads
    int writeCount; //number of disk writes
    int globalCounter;  //global access counter
} BP_MgmtData;

// Helper function declarations
static Frame *findFrameByPage(BP_MgmtData *pool, PageNumber pageNum);
static Frame *findEmptyFrame(BP_MgmtData *pool);
static Frame *selectVictim(BP_MgmtData *pool);
static void updateAccessHistory(Frame *frame, int counter, int k);
static int calculateEvictionPriority(Frame *frame, ReplacementStrategy strategy);
static RC loadPageToFrame(BP_MgmtData *pool, Frame *frame, PageNumber pageNum);
static RC saveFrameContent(BP_MgmtData *pool, Frame *frame);

// ========== CRITICAL FIXES ========== //
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName,
                  const int numPages, ReplacementStrategy strategy, void *stratData) {
    if (bm == NULL || pageFileName == NULL || numPages <= 0)
        return RC_FILE_HANDLE_NOT_INIT;

    BP_MgmtData *pool = (BP_MgmtData *)calloc(1, sizeof(BP_MgmtData));
    if (pool == NULL)
        return RC_MEM_ALLOC_FAILED;

    RC rc = openPageFile((char *)pageFileName, &pool->fh);
    if (rc != RC_OK) {
        free(pool);
        bm->mgmtData = NULL; // Reset to prevent invalid access
        return rc;
    }

    pool->frames = (Frame *)calloc(numPages, sizeof(Frame));
    if (pool->frames == NULL) {
        closePageFile(&pool->fh);
        free(pool);
        bm->mgmtData = NULL; // Ensure clean state
        return RC_MEM_ALLOC_FAILED;
    }

    int lruK = 1;
    if (strategy == RS_LRU_K && stratData != NULL)
        lruK = *((int *)stratData);

    for (int i = 0; i < numPages; i++) {
        pool->frames[i].data = (char *)malloc(PAGE_SIZE);
        if (pool->frames[i].data == NULL) {
            // Cleanup all previously allocated frames
            for (int j = 0; j < i; j++) {
                free(pool->frames[j].data);
                if (pool->frames[j].accessHistory)
                    free(pool->frames[j].accessHistory);
            }
            free(pool->frames);
            closePageFile(&pool->fh);
            free(pool);
            bm->mgmtData = NULL; // Critical fix
            return RC_MEM_ALLOC_FAILED;
        }

        pool->frames[i].pageNum = NO_PAGE;
        pool->frames[i].isDirty = false;
        pool->frames[i].fixCount = 0;
        pool->frames[i].loadTime = -1;

        if (strategy == RS_LRU_K) {
            pool->frames[i].k = lruK;
            pool->frames[i].accessHistory = (int *)malloc(lruK * sizeof(int));
            if (pool->frames[i].accessHistory == NULL) {
                free(pool->frames[i].data);
                for (int j = 0; j < i; j++) {
                    free(pool->frames[j].data);
                    if (pool->frames[j].accessHistory)
                        free(pool->frames[j].accessHistory);
                }
                free(pool->frames);
                closePageFile(&pool->fh);
                free(pool);
                bm->mgmtData = NULL; // Reset on failure
                return RC_MEM_ALLOC_FAILED;
            }
            for (int j = 0; j < lruK; j++)
                pool->frames[i].accessHistory[j] = -1;
        } else if (strategy == RS_LRU) {
            pool->frames[i].k = 1;
            pool->frames[i].accessHistory = (int *)malloc(sizeof(int));
            if (pool->frames[i].accessHistory == NULL) {
                free(pool->frames[i].data);
                for (int j = 0; j < i; j++) {
                    free(pool->frames[j].data);
                    if (pool->frames[j].accessHistory)
                        free(pool->frames[j].accessHistory);
                }
                free(pool->frames);
                closePageFile(&pool->fh);
                free(pool);
                bm->mgmtData = NULL;
                return RC_MEM_ALLOC_FAILED;
            }
            pool->frames[i].accessHistory[0] = -1;
        } else {
            pool->frames[i].k = 0;
            pool->frames[i].accessHistory = NULL;
        }
    }

    pool->numFrames = numPages;
    pool->strategy = strategy;
    pool->readCount = 0;
    pool->writeCount = 0;
    pool->globalCounter = 0;
    bm->pageFile = (char *)pageFileName;
    bm->numPages = numPages;
    bm->strategy = strategy;
    bm->mgmtData = pool;
    return RC_OK;
}

RC shutdownBufferPool(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    BP_MgmtData *pool = (BP_MgmtData *)bm->mgmtData;
    for (int i = 0; i < pool->numFrames; i++) {
        if (pool->frames[i].fixCount > 0)
            return RC_PINNED_PAGES_IN_BUFFER;
    }

    for (int i = 0; i < pool->numFrames; i++) {
        Frame *frame = &pool->frames[i];
        if (frame->pageNum != NO_PAGE) {
            if (frame->isDirty) {
                RC rc = saveFrameContent(pool, frame);
                if (rc != RC_OK)
                    return rc;
            }
            free(frame->data);
            if (frame->accessHistory)
                free(frame->accessHistory);
        }
    }

    closePageFile(&pool->fh);
    free(pool->frames);
    free(pool);
    bm->mgmtData = NULL; // Prevent dangling pointer
    return RC_OK;
}

// ========== PAGE REPLACEMENT FIX (LRU-K) ========== //
static int calculateEvictionPriority(Frame *frame, ReplacementStrategy strategy) {
    switch (strategy) {
        case RS_FIFO:
            return frame->loadTime;
        case RS_LRU:
            return frame->accessHistory[0];
        case RS_LRU_K:
            if (frame->k <= 1) {
                return frame->accessHistory[0];
            } else {
                // Find the oldest access within the K history
                for (int i = frame->k - 1; i >= 0; i--) {
                    if (frame->accessHistory[i] != -1) {
                        return frame->accessHistory[i];
                    }
                }
                return -1; // If all history is -1, treat as lowest priority
            }
        default:
            return INT_MAX;
    }
}

// ========== REMAINING FUNCTIONS ========== //
//Writes all dirty pages to disk if they arenot pinned
RC forceFlushPool(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    BP_MgmtData *pool = (BP_MgmtData *)bm->mgmtData;
    for (int i = 0; i < pool->numFrames; i++) {
        Frame *frame = &pool->frames[i];
        if (frame->isDirty && frame->fixCount == 0 && frame->pageNum != NO_PAGE) {
            RC rc = saveFrameContent(pool, frame);
            if (rc != RC_OK)
                return rc;
        }
    }
    return RC_OK;
}

//Pins page into buffer pool with loading if necessary
RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum) {
    if (bm == NULL || bm->mgmtData == NULL || page == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    BP_MgmtData *pool = (BP_MgmtData *)bm->mgmtData;

    // Ensure the file has enough pages to accommodate pageNum
    RC rc = ensureCapacity(pageNum + 1, &pool->fh);  // <-- SINGLE DECLARATION
    if (rc != RC_OK) {
        return rc;
    }

    // Validate pageNum against the file's total pages
    if (pageNum < 0 || pageNum >= pool->fh.totalNumPages)
        return RC_READ_NON_EXISTING_PAGE;

    // Check if page is already in buffer pool
    Frame *frame = findFrameByPage(pool, pageNum);
    if (frame != NULL) {
        // Page is already in buffer, increment fix count
        frame->fixCount++;
        if (pool->strategy == RS_LRU || pool->strategy == RS_LRU_K)
            updateAccessHistory(frame, pool->globalCounter++, frame->k);
        page->pageNum = pageNum;
        page->data = frame->data;
        return RC_OK;
    }

    // Page is not in buffer, find an empty frame or select a victim
    frame = findEmptyFrame(pool);
    if (frame == NULL)
        frame = selectVictim(pool);
    if (frame == NULL)
        return RC_NO_FREE_BUFFER_SLOT; // Now this correctly means all frames are pinned

    // If frame has a page, save it if dirty
    if (frame->pageNum != NO_PAGE) {
        rc = saveFrameContent(pool, frame);  
        if (rc != RC_OK)
            return rc;
    }

    // Load the requested page into the frame
    rc = loadPageToFrame(pool, frame, pageNum);  
    if (rc != RC_OK)
        return rc;

    frame->fixCount = 1;
    frame->pageNum = pageNum;
    page->pageNum = pageNum;
    page->data = frame->data;
    
    // Update access history for replacement strategies
    if (pool->strategy == RS_LRU || pool->strategy == RS_LRU_K)
        updateAccessHistory(frame, pool->globalCounter, frame->k);
    
    pool->globalCounter++;
    return RC_OK;
}

// Helper functions (unchanged but included for completeness)
static Frame *selectVictim(BP_MgmtData *pool) {
    Frame *victim = NULL;
    int minPriority = INT_MAX;
    for (int i = 0; i < pool->numFrames; i++) {
        Frame *frame = &pool->frames[i];
        if (frame->fixCount != 0)
            continue;
        int priority = calculateEvictionPriority(frame, pool->strategy);
        if (priority < minPriority) {
            minPriority = priority;
            victim = frame;
        }
    }
    return victim;
}

static void updateAccessHistory(Frame *frame, int counter, int k) {
    if (k <= 0 || frame->accessHistory == NULL)
        return;
    for (int i = k - 1; i > 0; i--)
        frame->accessHistory[i] = frame->accessHistory[i - 1];
    frame->accessHistory[0] = counter;
}

static Frame *findFrameByPage(BP_MgmtData *pool, PageNumber pageNum) {
    for (int i = 0; i < pool->numFrames; i++) {
        if (pool->frames[i].pageNum == pageNum)
            return &pool->frames[i];
    }
    return NULL;
}

static Frame *findEmptyFrame(BP_MgmtData *pool) {
    for (int i = 0; i < pool->numFrames; i++) {
        if (pool->frames[i].pageNum == NO_PAGE)
            return &pool->frames[i];
    }
    return NULL;
}

static RC loadPageToFrame(BP_MgmtData *pool, Frame *frame, PageNumber pageNum) {
    RC rc = readBlock(pageNum, &pool->fh, frame->data);
    if (rc != RC_OK)
        return rc;
    frame->pageNum = pageNum;
    frame->isDirty = false;
    frame->fixCount = 1;
    frame->loadTime = pool->globalCounter;  
    pool->globalCounter++;                  
    if (pool->strategy == RS_LRU || pool->strategy == RS_LRU_K)
        updateAccessHistory(frame, frame->loadTime, frame->k);
    pool->readCount++;
    return RC_OK;
}

static RC saveFrameContent(BP_MgmtData *pool, Frame *frame) {
    if (!frame->isDirty)
        return RC_OK;
    RC rc = writeBlock(frame->pageNum, &pool->fh, frame->data);
    if (rc != RC_OK)
        return rc;
    frame->isDirty = false;
    pool->writeCount++;
    return RC_OK;
}

//unpins page, reducing fix count
RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page) {
    if (bm == NULL || bm->mgmtData == NULL || page == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    BP_MgmtData *pool = (BP_MgmtData *)bm->mgmtData;
    Frame *frame = findFrameByPage(pool, page->pageNum);
    if (frame == NULL)
        return RC_PAGE_NOT_IN_BUFFER;
    if (frame->fixCount <= 0)
        return RC_INVALID_UNPIN;
    frame->fixCount--;
    return RC_OK;
}

//marks page as dirty, needs to be written back to disk
RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page) {
    if (bm == NULL || bm->mgmtData == NULL || page == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    BP_MgmtData *pool = (BP_MgmtData *)bm->mgmtData;
    Frame *frame = findFrameByPage(pool, page->pageNum);
    if (frame == NULL)
        return RC_PAGE_NOT_IN_BUFFER;
    frame->isDirty = true;
    return RC_OK;
}

//forces page to be written to disk
RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page) {
    if (bm == NULL || bm->mgmtData == NULL || page == NULL)
        return RC_FILE_HANDLE_NOT_INIT;

    BP_MgmtData *pool = (BP_MgmtData *)bm->mgmtData;
    Frame *frame = findFrameByPage(pool, page->pageNum);
    if (frame == NULL)
        return RC_PAGE_NOT_IN_BUFFER;
    return saveFrameContent(pool, frame);
}

// Statistics functions
//returns array containing page numbers in each frame
PageNumber *getFrameContents(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL)
        return NULL;
    BP_MgmtData *pool = (BP_MgmtData *)bm->mgmtData;
    PageNumber *contents = (PageNumber *)malloc(pool->numFrames * sizeof(PageNumber));
    for (int i = 0; i < pool->numFrames; i++)
        contents[i] = pool->frames[i].pageNum;
    return contents;
}

//returns an array that contains which frames are dirty
bool *getDirtyFlags(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL)
        return NULL;
    BP_MgmtData *pool = (BP_MgmtData *)bm->mgmtData;
    bool *flags = (bool *)malloc(pool->numFrames * sizeof(bool));
    for (int i = 0; i < pool->numFrames; i++)
        flags[i] = pool->frames[i].isDirty;
    return flags;
}

//returns array containing fix ocunt of each frame
int *getFixCounts(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL)
        return NULL;
    BP_MgmtData *pool = (BP_MgmtData *)bm->mgmtData;
    int *counts = (int *)malloc(pool->numFrames * sizeof(int));
    for (int i = 0; i < pool->numFrames; i++)
        counts[i] = pool->frames[i].fixCount;
    return counts;
}

//returns number of pages read from disk since buffer pool was initialized
int getNumReadIO(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL)
        return -1;
    return ((BP_MgmtData *)bm->mgmtData)->readCount;
}
//returns number of pages written to disk since buffer pool was initialized
int getNumWriteIO(BM_BufferPool *const bm) {
    if (bm == NULL || bm->mgmtData == NULL)
        return -1;
    return ((BP_MgmtData *)bm->mgmtData)->writeCount;
}